import react from "react";

import "./App.css";
import Navbar from "./components/navbar/Navbar";
import Home from "./pages/home/Home";
import Footer from "./components/footer/Footer";
import { Route, Routes } from "react-router-dom";
import Dupe from "./pages/Dupe";



function App() {

  return (
    <div style={{ position: "relative" }} className="lexend-fontFamily">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/coming-soon" element={<Dupe/>}/>
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
