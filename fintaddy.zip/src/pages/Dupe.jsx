import React, { useEffect } from "react";
import Button from "react-bootstrap/esm/Button";
import { Link } from "react-router-dom";

function Dupe() {
    useEffect(() => {
        // Scroll to the top of the page when the component mounts
        window.scrollTo(0, 0);
      }, []);
  return (
    <div
      style={{
        width: "100%",
        height: "80vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center ",
        backgroundColor: "rgba(211, 204, 217, 1)",
        flexDirection: "column",
      }}
    >
      <strong style={{ fontSize: "40px" }}>
        Sorry for the inconvenience...
      </strong>
      <h4>Shop will be added in the future...</h4>

      <div
        style={{ width: "100%", display: "flex", justifyContent: "center " }}
      >
        <Button  style={{
              backgroundColor: "#EF485C",
              padding: "10px 15px",
              color: "white",
              border: "none",
              borderRadius: "5px",
              fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
            }}>
          <Link to={"/"} style={{ color: "white",textDecoration:"none" }}>
            Go to Home
          </Link>
        </Button>
      </div>
    </div>
  );
}

export default Dupe;
