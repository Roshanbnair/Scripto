import React, { useEffect } from "react";
import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import "./navbar.css";
import logo from "../../../public/logo.png";
import Nav from "react-bootstrap/Nav";
import useSmoothScroll from "../UseSmoothScroll";
const Navbar = () => {
  const [click, setClick] = useState(true);
  const [activeIndex, setActiveIndex] = useState(null);
  const [scrollY, setScrollY] = useState(0);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 700);

  const handleClickMenu = () => setClick(!click);

  const handleItemClick = (index) => {
    setActiveIndex(index);
    setClick(false); // Close menu after clicking item
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    const handleResize = () => {
      setIsMobile(window.innerWidth < 700);
    };

    window.addEventListener("scroll", handleScroll);
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  useSmoothScroll();
  return (
    <>
      {/* <img src={logo} alt="" /> */}
      <nav
        className="navbar"
        style={{
          height: "150px",
          position: "fixed",
          backgroundColor:
            isMobile && scrollY > 400 ? "rgba(0,0,0,0.4  )" : "transparent",
          transition: "background-color 0.3s ease",
          zIndex: "10",
        }}
        // style={
        //   {
        //     //  padding: "0px 100px",
        //   }
        // }
      >
        <div
          className={click ? "nav-container nav-burger-color" : "nav-container"}
        >
          <NavLink exact to="/" className="nav-logo">
            <div
              style={{
                height: "100px",
                display: "flex",
                width: "155px",
                justifyContent: "space-around",
                alignItems: "center",
                // marginBottom: "16px",
              }}
              className="logo-size"
            >
              <img
                src={logo}
                alt=""
                style={{
                  height: "100%",

                  objectFit: "contain",
                }}
              />{" "}
            </div>
            <p></p>
          </NavLink>
          <div
            className="left-nav-content"
            style={{
              // position:"relative",
              display: "flex",
              justifyContent: "center",
              width: "55%",
              alignItems: "center",
              height: "50%",
              fontFamily: "Mulish, sans-serif",
              fontWeight: "400",
              FontStyle: "normal",
              backgroundColor: "rgba(128, 128, 128, 0.6)",
              borderRadius: "10px 0 0 10px",
            }}
          >
            <ul className={!click ? "nav-menu active" : "nav-menu"}>
              <li className="nav-item special" style={{marginBottom:"3px"}}>
                <Link
                  to="/"
                  exact
                  // className="nav-links"
                  onClick={handleClickMenu}
                  style={{
                    fontSize: "clamp(0.75rem, 0.703rem + 0.2151vw, 0.875rem)"
                  }}
                  className={`nav-links ${
                    click ? "nav-links active" : "nav-links"
                  }`} 
                >
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Nav.Link
                  href="#aboutUs"
                  // exact

                  // activeclassname="active"
                  className={`nav-links ${
                    click ? "nav-links active" : "nav-links"
                  }`}
                  onClick={handleClickMenu}
                  style={{
                    fontSize: "clamp(0.75rem, 0.703rem + 0.2151vw, 0.875rem)",
                  }}
                >
                  About us
                </Nav.Link>
              </li>
              <li className="nav-item">
                <Nav.Link
                  // exact
                  href="#service"
                  className={`nav-links ${
                    click ? "nav-links active" : "nav-links"
                  }`}
                  onClick={handleClickMenu}
                  style={{
                    fontSize: "clamp(0.75rem, 0.703rem + 0.2151vw, 0.875rem)",
                  }}
                >
                  Services
                </Nav.Link>
              </li>
              <li className="nav-item">
                <Nav.Link
                  // exact
                  href="#testimonials"
                  className={`nav-links ${
                    click ? "nav-links active" : "nav-links"
                  }`}
                  onClick={handleClickMenu}
                  style={{
                    fontSize: "clamp(0.75rem, 0.703rem + 0.2151vw, 0.875rem)",
                  }}
                >
                  Testimonials
                </Nav.Link>
              </li>
              <li className="nav-item">
                <Nav.Link
                  // exact
                  href="#contactUs"
                  className={`nav-links ${
                    click ? "nav-links active" : "nav-links"
                  }`}
                  onClick={handleClickMenu}
                  style={{
                    fontSize: "clamp(0.75rem, 0.703rem + 0.2151vw, 0.875rem)",
                  }}
                >
                  Contact us
                </Nav.Link>
              </li>
            </ul>

            <div
              className="nav-icon"
              style={{ color: "white" }}
              onClick={handleClickMenu}
            >
              {click ? (
                <i className="fa-solid fa-bars"></i>
              ) : (
                <i className="fa-solid fa-xmark"></i>
              )}
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
