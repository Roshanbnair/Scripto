import React from "react";
import "./contact.css";

const Contact = () => {
  return (
    <div id="contactUs"
      className="outer-contact"
      style={{
        width: "100%",
        display: "flex",
        justifyContent: "space-between",
        backgroundColor: "yellow",
        height: "auto",
        padding: "100px",
        position: "relative",
        alignItems: "center",
      }}
    >
      <div
        className="black-blur"
        style={{ width: "100%", height: "100%" }}
      ></div>

      {/* LEFT */}
      <div
        className="left-form"
        style={{ width: "40%", height: "auto", zIndex: "3" }}
      >
        <form
          action=""
          style={{
            width: "100%",
            height: "400px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            zIndex: "10",
          }}
        >
          <input
            className="input-field"
            type="text"
            placeholder="Name"
            style={{
              border: "none",
              backgroundColor: "transparent",
              borderBottom: "2px solid white",
              outline: "none",fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)"
            }}
          />
          <input
            className="input-field"
            type="text"
            placeholder="E mail"
            style={{
              border: "none",
              backgroundColor: "transparent",
              borderBottom: "2px solid white",
              outline: "none",fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)"
            }}
          />
          <input
            className="input-field"
            type="text"
            placeholder="Contact Number"
            style={{
              border: "none",
              backgroundColor: "transparent",
              borderBottom: "2px solid white",
              outline: "none",fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)"
            }}
          />
          <textarea
            className="input-field"
            rows="6"
            cols="20"
            type="t"
            placeholder="Your Message"
            style={{
              border: "none",
              backgroundColor: "transparent",
              borderBottom: "2px solid white",
              outline: "none",fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)"
            }}
          />
          <button
            style={{
              backgroundColor: "#EF485C",
              padding: "10px 15px",
              color: "white",
              border: "none",
              borderRadius: "5px",
              fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
              width: "150px",
            }}
          >
            Submit
          </button>
        </form>
      </div>

      {/* RIGHT */}
      <div
        className="right-contact"
        style={{ width: "50%", height: "auto", zIndex: "3" }}
      >
        <p className="title-team" style={{ color: "white" }}>
          Contact US
        </p>
        <p
          style={{
            fontSize: "clamp(1.25rem, -0.3125rem + 5vw, 2.5rem)",
            fontWeight: "600",
            color: "white",
            marginTop: "0px",
          }}
        >
          Reach Our <span style={{ color: "#EF485C" }}>Support Team</span>{" "}
        </p>
        <p
          style={{
            color: "white",
            textAlign: "justify",
            fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
          }}
        >
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sint id,
          deserunt ipsa suscipit, doloribus repellendus debitis expedita
          accusantium ea tempora voluptates itaque maxime harum quidem aliquam
          quae officia laudantium delectus?
        </p>
      </div>
    </div>
  );
};

export default Contact;
