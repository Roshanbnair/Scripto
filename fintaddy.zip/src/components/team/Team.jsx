import React from "react";
import "./team.css";
import jacob from "../../../public/teamjacob.png";
import ron from "../../../public/teamronaldo.png";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";

const Team = () => {
  return (
    <div id="team" className="team-outer "
      style={{
        backgroundColor: "#FFECEE",
        width: "100%",
        height: "500px",
        padding: "100px",
        display: "flex",
        justifyContent: "space-around",
        alignItems: "center",
      }}
    >
      {/* LEFT */}
      <div className="text-left-side" style={{ width: "40%", height: "auto" }}>
        <p className="title-team">Our Team</p>
        <p
          style={{
            fontSize: "clamp(1.25rem, -0.3125rem + 5vw, 2.5rem)",
            fontWeight: "600",
          }}
        >
          Meet with Our{" "}
          <span style={{ color: "#EF485C" }}>Expert Advisors</span>{" "}
        </p>
        <p style={{textAlign:"justify", fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",}}>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusamus,
          nihil. Repellendus, eaque ipsum? Aut quos ratione repellendus eius ut
          impedit tenetur fugit repudiandae dignissimos. Repellat ratione
          mollitia aliquid quam officiis!
        </p>
      </div>
      <div
        className="caroausel"
        style={{
          width: "45%",
          height: "auto",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <img className="first-pic" src={jacob} alt="" style={{width:'250px',height:'250px'}} />
        <img className="second-pic" src={ron} alt="" style={{width:'250px',height:'250px'}}  />
      </div>
    </div>
  );
};

export default Team;
// 