import React from "react";
import "./footer.css";
import logo from "../../../public/logosmall.png";
import fb from "../../../public/fb.png";
import insta from "../../../public/insta.png";
import li from "../../../public/li.png";
import twi from "../../../public/twi.png";
import phone from "../../../public/phone.png";
import mail from "../../../public/mail.png";
import locat from "../../../public/locat.png";
import copy from "../../../public/copy.png";

const Footer = () => {
  return (
    <div style={{ backgroundColor: "#FFD2D8" }}>
      <div
        className="footer-outest"
        style={{
          width: "100%",
          height: "400px",
          padding: "60px 100px",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        {/* LEFT */}
        <div
          className="main-footer"
          style={{
            width: "40%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <img
            className="footer-logo"
            src={logo}
            style={{ width: "200px" }}
            alt=""
          />
          <p
            style={{
              color: "#EF485C",
              textAlign: "justify",
              fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
            }}
          >
            Our mission is to provide exceptional accounting, tax, and financial
            advisory services that empower our clients to reach their financial
            goals. We strive to build long-lasting relationships based on trust,
            integrity, and professionalism.
          </p>
          <div
            className="icons"
            style={{
              width: "150px",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <img src={fb} alt="" className="img-footer-icon" />
            <img src={insta} alt="" className="img-footer-icon" />
            <img src={li} alt="" className="img-footer-icon" />
            <img src={twi} alt="" className="img-footer-icon" />
          </div>
        </div>
        {/* RIGHT */}
        <div
          className="right-footer"
          style={{
            width: "50%",
            height: "auto",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <div
            className="first"
            style={{
              width: "50%",
              height: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <p
              style={{
                fontWeight: "600",
                color: "#EF485C",
                marginBottom: "20px",
              }}
            >
              Quicklinks
            </p>

            <p
              style={{
                color: "#EF485C",
                fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
              }}
            >
              About us
            </p>
            <p
              style={{
                color: "#EF485C",
                fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
              }}
            >
              Services
            </p>
            <p
              style={{
                color: "#EF485C",
                fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
              }}
            >
              Blogs
            </p>
            <p
              style={{
                color: "#EF485C",
                fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
              }}
            >
              Testimonials
            </p>
            <p
              style={{
                color: "#EF485C",
                fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
              }}
            >
              Contact us
            </p>
          </div>
          <div
            className="last"
            style={{
              width: "50%",
              height: "250px",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              className="one"
              style={{
                display: "flex",
                width: "100%",
                justifyContent: "space-between",
                alignItems: "start",
                height: "auto",
              }}
            >
              <img className="me-2 mt-1 img-footer-icon" src={locat} alt="" />
              <p
                style={{
                  color: "#EF485C",
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                67/3238, Putheth Building, St Alberts College Road, Ernakulam
                682018
              </p>
            </div>
            <div
              className="two"
              style={{
                display: "flex",
                width: "100%",
                // justifyContent: "space-between",
                alignItems: "start",
              }}
            >
              <img src={phone} alt="" className="mt-1 me-2 img-footer-icon" />
              <p
                style={{
                  color: "#EF485C",
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                +91 9048 72 0020 , 9947 31 6616
              </p>
            </div>
            <div
              className="three"
              style={{
                display: "flex",
                width: "100%",
                // justifyContent: "space-between",
                alignItems: "start",
              }}
            >
              <img src={mail} alt="" className=" me-2 img-footericon" />
              <p
                style={{
                  color: "#EF485C",
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                info@fintaddy.com
              </p>
            </div>
          </div>
        </div>
      </div>
      <hr style={{ color: "#EF485C", width: "90%", margin: "10px" }} />
      <div
        style={{
          width: "100%",
          display: "flex",
          height: "30px",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <img
          src={copy}
          style={{ width: "15px", height: "15px" }}
          className="me-1"
          alt=""
        />
        <p
          style={{
            margin: "0px",
            color: "#EF485C",
            fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
          }}
        >
          2024 fintaddy.com - All rights reserved.
        </p>
      </div>{" "}
    </div>
  );
};

export default Footer;
