import React from "react";
import banner from ".././../../public/banner.jpeg";
import "./banner.css"
import { Link } from "react-router-dom";
const Banner = () => {
  return (
    <div style={{ height: "800px", width: "100%" }} className="banner-outer-fin" id="home">
      <img
        src={banner}
        alt=""
        style={{ height: "100%", width: "100%", objectFit: "cover" }}
      />
      <div
        className="banner-text-div"
        style={{
          display: "flex",
          // height: "600px",
          width: "400px",
          alignItems: "center",
          flexDirection: "column",
          justifyContent: "start",
          position: "absolute",
          top: "300px",
          left: "100px",
          textAlign: "start",
        }}
      >
        <p
          className="text-start"
          style={{
            color: "white",
            fontSize: "clamp(1.25rem, 0.0781rem + 3.75vw, 2.1875rem)",
            fontWeight: "600",
          }}
        >
          Your Trusted Partner in Financial Success...
        </p>
        <p
          className="small-text-banner"
          style={{
            color: "white",
            fontSize: "clamp(0.75rem, 0.5156rem + 0.75vw, 0.9375rem)",
          }}
        >
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
        <div style={{ width: "100%", height: "auto" }}>
          {/* <Link to={"/collections/Ladies"}> */}
          <button
            className=""
            style={{
              backgroundColor: "#EF485C",
              padding: "10px 15px",
              color: "white",
              border: "none",
              borderRadius: "5px",
              fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
            }}

          >
            <Link style={{textDecoration:"none",color:"white"}} to={"/coming-soon"}>
            Make an Appointment
            </Link>
          </button>
          {/* </Link> */}
        </div>
      </div>
    </div>
  );
};

export default Banner;
