import React from "react";
import "./service.css";
import audit from "../../../public/audit.png";
import book from "../../../public/book.png";
import bussiness from "../../../public/bussiness.png";
import corpo from "../../../public/corpo.png";
import payroll from "../../../public/payroll.png";
import tax from "../../../public/tax.png";
import center from "../../../public/center-service.png";

const Service = () => {
  return (
    <div id="service" className="service-outest" style={{ width: "100%", height: "auto" }}>
      <div
        className="title-service-headings"
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          flexDirection: "column",
        }}
      >
        <p className="title-service" style={{ fontSize: "16px" }}>
          Our Services
        </p>
        <p
          className="ms-3"
          style={{
            fontSize: "clamp(1.25rem, -0.3125rem + 5vw, 2.5rem)",
            fontWeight: "600",
          }}
        >
          Committed to Your{" "}
          <span style={{ color: "#EF485C" }}>Financial Growth </span>{" "}
        </p>
      </div>

      {/* MAIN DIV */}
      <div
        className="outer-service-rows"
        style={{
          display: "flex",
          justifyContent: "space-between",
          //   backgroundColor: "yellow",
          padding: "50px",
          alignItems: "center",
        }}
      >
        {/* LEFT */}
        <div className="left-service" style={{ width: "30%" }}>
          <div
            className="each-text"
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="icon">
              <img src={tax} alt="" className="service-icon" />
            </div>
            <div className="text-only" style={{ width: "80%" }}>
              <p
                style={{
                  fontWeight: "600",
                  fontSize: "clamp(1rem, 0.9548rem + 0.2128vw, 1.125rem)",
                  color: "#EF485C",
                }}
              >
                Tax Planning and Preparation
              </p>
              <p
                style={{
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                Strategic tax planning and accurate tax return preparation for
                individuals and businesses.
              </p>
            </div>
          </div>
          <div
            className="each-text"
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="icon">
              <img src={book} alt=""  className="service-icon" />
            </div>
            <div className="text-only" style={{ width: "80%" }}>
              <p
                style={{
                  fontWeight: "600",
                  fontSize: "clamp(1rem, 0.9548rem + 0.2128vw, 1.125rem)",
                  color: "#EF485C",
                }}
              >
                Bookkeeping
              </p>
              <p
                style={{
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                Accurate and efficient bookkeeping services to keep your
                financial records up to date.
              </p>
            </div>
          </div>
          <div
            className="each-text"
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="icon">
              <img src={audit} alt=""  className="service-icon" />
            </div>
            <div className="text-only" style={{ width: "80%" }}>
              <p
                style={{
                  fontWeight: "600",
                  fontSize: "clamp(1rem, 0.9548rem + 0.2128vw, 1.125rem)",
                  color: "#EF485C",
                }}
              >
                Audit and Assurance
              </p>
              <p
                style={{
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                Ensuring your business adheres to financial regulations and
                industry standards.
              </p>
            </div>
          </div>
        </div>

        {/* CENTER */}
        <div className="center-image" style={{ width: "30%" }}>
          <img src={center} alt="" style={{ width: "100%" }} />
        </div>
        {/* RIGHT */}
        <div className="right-service" style={{ width: "30%" }}>
          <div
            className="each-text"
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="icon">
              <img src={bussiness} alt=""  className="service-icon" />
            </div>
            <div className="text-only" style={{ width: "80%" }}>
              <p
                style={{
                  fontWeight: "600",
                  fontSize: "clamp(1rem, 0.9548rem + 0.2128vw, 1.125rem)",
                  color: "#EF485C",
                }}
              >
                Business Advisory and Analysis
              </p>
              <p
                style={{
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                Strategic advice to enhance business growth and profitability
                and expertise in financial planning and analysis.
              </p>
            </div>
          </div>
          <div
            className="each-text"
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="icon">
              <img src={corpo} alt=""  className="service-icon" />
            </div>
            <div className="text-only" style={{ width: "80%" }}>
              <p
                style={{
                  fontWeight: "600",
                  fontSize: "clamp(1rem, 0.9548rem + 0.2128vw, 1.125rem)",
                  color: "#EF485C",
                }}
              >
                Corporate Finance
              </p>
              <p
                style={{
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                Advisory services for mergers, acquisitions, and business
                valuations .
              </p>
            </div>
          </div>
          <div
            className="each-text"
            style={{
              display: "flex",
              justifyContent: "space-between",
              width: "100%",
            }}
          >
            <div className="icon">
              <img src={payroll} alt=""  className="service-icon" />
            </div>
            <div className="text-only" style={{ width: "80%" }}>
              <p
                style={{
                  fontWeight: "600",
                  fontSize: "clamp(1rem, 0.9548rem + 0.2128vw, 1.125rem)",
                  color: "#EF485C",
                }}
              >
                Payroll Services
              </p>
              <p
                style={{
                  fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
                }}
              >
                Efficient and accurate payroll processing for businesses of all
                sizes and managing employee benefits and compensation plans..
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Service;
