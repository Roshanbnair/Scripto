import React from "react";
import "./navigate.css";
import proff from "../../../public/proff.png";
import innov from "../../../public/innov.png";
import { Link } from "react-router-dom";

const Navigate = () => {
  return (
    <div style={{ height: "auto", width: "100%", position: "relative" }}>
      <div
        className="black"
        style={{
          width: "100%",
          height: "500px",
          backgroundColor: "black",
          padding: "100px",
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <div
          className="navigator-heading"
          style={{ width: "60%", height: "auto" }}
        >
          <p
            style={{
              color: "#EF485C",
              fontSize: "clamp(1.125rem, -0.9844rem + 6.75vw, 2.8125rem)",
              fontWeight: "600",
            }}
          >
            Navigating Your Financial Future Together
          </p>
        </div>
        <div
          className="navigator-text"
          style={{
            width: "40%",
            height: "auto",
            padding: "20px 10px",
            color: "white",
            textAlign: " justify",
          }}
        >
          <p style={{ fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)" }}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis,
            sequi inventore tempore eaque, minus eveniet enim, repellendus
            suscipit amet autem sed nisi. Nostrum laborum tempora odit ullam
            quam iste itaque!
          </p>
        </div>
      </div>
      <div
        className="cards-outer"
        style={{
          width: "100%",
          display: "flex",
          padding: "20px 50px",
          //   backgroundColor: "yellow",
          position: "absolute",
          top: "300px",
          height: "auto",
          justifyContent: "space-around",
          flexWrap: "wrap",
        }}
      >
        <div
          className="single-card"
          style={{
            height: "400px",
            width: "300px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: "white",
            padding: "60px 30px",
            borderRadius: "5px",
            boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
          }}
        >
          <i
            className="icon fa-solid fa-lightbulb"
            style={{
              color: "#EF485C",
              fontSize: "clamp(2.5rem, 1.7188rem + 2.5vw, 3.125rem)",
            }}
          ></i>
          <div
            className="heading"
            style={{
              fontSize: "clamp(1rem, 0.9096rem + 0.4255vw, 1.25rem)",
              fontWeight: "600",
            }}
          >
            Innovative Solutions
          </div>
          <p
            className="text"
            style={{
              textAlign: "center",
              fontSize: "clamp(0.875rem, 0.8524rem + 0.1064vw, 0.9375rem) ",
            }}
          >
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem
            praesentium molestias nobis accusantium vero eligendi
          </p>
          <button
            className="button-nav"
            style={{
              color: "#EF485C",
              border: "none",
              backgroundColor: "transparent",
              fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
              cursor: "default",
            }}
          >
            Read More
            <Link
              to={"/coming-soon"}
              style={{ color: "white", textDecoration: "none" }}
            >
              <i className="arrow fa-solid fa-arrow-right-long ms-2"></i>
            </Link>
          </button>
        </div>
        <div
          className="single-card"
          style={{
            height: "400px",
            width: "300px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: "white",
            padding: "60px 30px",
            borderRadius: "5px",
            boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
          }}
        >
          <i
            className="icon fa-solid fa-people-group"
            style={{
              color: "#EF485C",
              fontSize: "clamp(2.5rem, 1.7188rem + 2.5vw, 3.125rem)",
            }}
          ></i>
          <div
            className="heading"
            style={{
              fontSize: "clamp(1rem, 0.9096rem + 0.4255vw, 1.25rem)",
              fontWeight: "600",
            }}
          >
            Professional Team
          </div>
          <p
            className="text"
            style={{
              textAlign: "center",
              fontSize: "clamp(0.875rem, 0.8524rem + 0.1064vw, 0.9375rem) ",
            }}
          >
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem
            praesentium molestias nobis accusantium vero eligendi
          </p>
          <button
            className="button-nav"
            style={{
              color: "#EF485C",
              border: "none",
              backgroundColor: "transparent",
              fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
              cursor: "default",
            }}
          >
            Read More
            <Link
              to={"/coming-soon"}
              style={{ color: "white", textDecoration: "none" }}
            >
              <i className="arrow  fa-solid fa-arrow-right-long ms-2"></i>
            </Link>
          </button>
        </div>
        <div
          className="single-card"
          style={{
            height: "400px",
            width: "300px",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            alignItems: "center",
            backgroundColor: "white",
            padding: "60px 30px",
            borderRadius: "5px",
            boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
          }}
        >
          <i
            style={{
              color: "#EF485C",
              fontSize: "clamp(2.5rem, 1.7188rem + 2.5vw, 3.125rem)",
            }}
            className="icon fa-solid fa-headset"
          ></i>
          <div
            className="heading"
            style={{
              fontSize: "clamp(1rem, 0.9096rem + 0.4255vw, 1.25rem)",
              fontWeight: "600",
            }}
          >
            24X7 Support
          </div>
          <p
            className="text"
            style={{
              textAlign: "center",
              fontSize: "clamp(0.875rem, 0.8524rem + 0.1064vw, 0.9375rem) ",
            }}
          >
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quidem
            praesentium molestias nobis accusantium vero eligendi
          </p>
          <button
            className="button-nav"
            style={{
              color: "#EF485C",
              border: "none",
              backgroundColor: "transparent",
              fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
              cursor: "default",
            }}
          >
            Read More
            <Link
              to={"/coming-soon"}
              style={{ color: "white", textDecoration: "none" }}
            >
              <i className="arrow  fa-solid fa-arrow-right-long ms-2"></i>
            </Link>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Navigate;
