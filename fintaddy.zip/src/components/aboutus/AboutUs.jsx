import React from "react";
import "./aboutUs.css";
import aboutus from "../../../public/aboutus.png";
import rectangle from "../../../public/rectangle.png";
import { Link } from "react-router-dom";

const AboutUs = () => {
  return (
    <div
      id="aboutUs"
      className="about-outer"
      style={{
        height: "600px",
        width: "100%",
        display: "flex",
        justifyContent: "space-between",
        marginTop: "350px",
        padding: "0px 100px",
        alignItems: "start",
      }}
    >
      <div
        className="image-rectangle"
        style={{
          position: "relative",
          backgroundColor: "blue",
          height: "auto",
        }}
      >
        <img
          className="real-image"
          src={aboutus}
          alt=""
          style={{ zIndex: "8", width: "450px", position: "absolute" }}
        />
        <img
          className="rectanle"
          src={rectangle}
          alt=""
          style={{
            position: "absolute",
            top: "210px",
            left: "350px",
            zIndex: "3",
          }}
        />
      </div>
      <div className="text-aboutus" style={{ width: "40%", marginTop: "50px" }}>
        {" "}
        {"             "}
        <p
          className="title-about"
          style={{
            fontSize: "16px",
            fontWeight: "600",
            marginLeft: "110px",
            width: "200px",
          }}
        >
          About Us
        </p>
        <p
          style={{
            fontSize: "clamp(1.25rem, -0.3125rem + 5vw, 2.5rem)",
            fontWeight: "600",
          }}
        >
          Experienced and <span style={{ color: "#EF485C" }}>Trusted</span>{" "}
        </p>
        <p
          style={{
            textAlign: "justify",
            fontSize: "clamp(0.75rem, 0.6596rem + 0.4255vw, 1rem)",
          }}
        >
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae
          neque atque, adipisci est quia ullam enim sequi cupiditate reiciendis
          voluptatem consectetur quasi itaque inventore. Quam quaerat eum labore
          repellendus.
        </p>
        <button
          style={{
            backgroundColor: "#EF485C",
            padding: "10px 15px",
            color: "white",
            border: "none",
            borderRadius: "5px",
            fontSize: "clamp(0.75rem, 0.4375rem + 1vw, 1rem)",
          }}
        >
          <Link
            to={"/coming-soon"}
            style={{ color: "white", textDecoration: "none" }}
          >
            Know More
          </Link>
        </button>
      </div>
    </div>
  );
};

export default AboutUs;
